# SPDX-License-Identifier: GPL-3.0-or-later
"""Vista Pictures VR Bridge: send the scene to Vista Pictures VR on a Meta Quest.

One button in the 3D View sidebar (N > Vista). The scene is copied, exported to glTF in a
background Blender — with its animation, shape keys, materials (procedural ones baked), World
HDRI, lamps and cameras — and sent over the local network to the headset, where a model already
on screen is replaced by the new version in place. The open .blend is never modified.

Also here: finding headsets on the network, sending to several at once, sending the render,
a check of the scene before sending, the versions kept on the headset, and letting Blender's
timeline drive the animation in VR.
"""
import json
import pathlib
import queue
import re
import tempfile
import threading
import time

import bpy
from bpy.app.handlers import persistent
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty,
                       PointerProperty, StringProperty)

from . import pipeline, scene_check, timeline, transport


def _prefs():
    return bpy.context.preferences.addons[__package__].preferences


# ---- properties ----------------------------------------------------------------------------


class VISTAPV_Headset(bpy.types.PropertyGroup):
    name: StringProperty(name="Name", description="What to call this headset", default="Quest")
    address: StringProperty(
        name="Address",
        description="The address shown in Vista: Home > Blender Bridge > START, e.g. http://192.168.1.28:8080",
    )
    enabled: BoolProperty(name="Send here", description="Send to this headset", default=True)


class VISTAPV_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    # Addresses are not secrets and typing them every session is the friction that makes a
    # bridge feel broken, so they live in the preferences. Credentials do not.
    headsets: CollectionProperty(type=VISTAPV_Headset)
    active_headset: IntProperty()
    # Where version 1.0 kept its one address. Read once, to carry it into the list above.
    address: StringProperty(options={"HIDDEN"})
    send_on_save: BoolProperty(
        name="Send on every save",
        description="Send the scene to the Quest each time the file is saved (Ctrl+S)",
        default=False,
    )
    sync_timeline: BoolProperty(
        name="Sync timeline",
        description="Scrubbing or playing Blender's timeline moves the animation in VR with it",
        default=False,
    )

    def draw(self, context):
        layout = self.layout
        _draw_headsets(layout, self)
        layout.prop(self, "send_on_save")
        layout.prop(self, "sync_timeline")
        layout.label(text="Start the server in Vista on the Quest: Home > Blender Bridge > START.")


class VISTAPV_SceneSettings(bpy.types.PropertyGroup):
    project: StringProperty(
        name="Project",
        description="Folder on the Quest for this scene's versions. Empty uses the file name",
        default="",
    )
    scope: EnumProperty(
        name="Send",
        items=[("SCENE", "Scene", "Every visible object"),
               ("SELECTION", "Selection", "Only the selected objects"),
               ("VARIANTS", "Variants", "One model per sub-collection of a collection you choose, "
                                        "to switch between in VR. Everything outside it is in all of them")],
        default="SCENE",
    )
    variants: PointerProperty(
        name="Variants in",
        type=bpy.types.Collection,
        description="The collection whose sub-collections are the variants",
    )
    animations: BoolProperty(name="Animation", description="Include animation, armatures and shape keys", default=True)
    animation_mode: EnumProperty(
        name="Animation as",
        items=[("TIMELINE", "Timeline", "One clip: the scene as it plays in Blender. Needed for Sync timeline"),
               ("ACTIONS", "Actions", "Every action as a clip of its own, to switch between in VR")],
        default="TIMELINE",
    )
    environment: BoolProperty(name="World HDRI", description="Light the model in VR with the World's HDRI", default=True)
    bake: BoolProperty(
        name="Bake procedural materials",
        description="Bake colours that cannot travel in glTF (procedural textures, shaders without "
                    "a Principled BSDF) to image textures. Done on a copy; your materials are not changed",
        default=True,
    )
    bake_size: EnumProperty(
        name="Bake size",
        items=[("512", "512", "Fastest"), ("1024", "1024", "A good default"), ("2048", "2048", "Sharpest; four times the bake time of 1024")],
        default="1024",
    )
    cameras: BoolProperty(name="Cameras", description="Send the cameras as places to stand in VR", default=True)
    lights: BoolProperty(name="Lamps", description="Light the model in VR with the scene's lamps", default=True)
    note: StringProperty(
        name="Note",
        description="What to call the next version you send, e.g. \"darker floor\". Shown on the Quest",
        default="",
    )


class VISTAPV_CheckLine(bpy.types.PropertyGroup):
    level: StringProperty()
    text: StringProperty()


class VISTAPV_Version(bpy.types.PropertyGroup):
    file: StringProperty()
    label: StringProperty()
    detail: StringProperty()
    kind: StringProperty()


class VISTAPV_Session(bpy.types.PropertyGroup):
    """Per-session state. Never saved into the .blend, so a shared file carries no password."""
    username: StringProperty(name="User", options={"SKIP_SAVE"})
    password: StringProperty(name="Password", subtype="PASSWORD", options={"SKIP_SAVE"})
    status: StringProperty(options={"SKIP_SAVE"})
    progress: FloatProperty(min=0.0, max=1.0, options={"SKIP_SAVE"})
    busy: BoolProperty(options={"SKIP_SAVE"})
    check: CollectionProperty(type=VISTAPV_CheckLine, options={"SKIP_SAVE"})
    versions: CollectionProperty(type=VISTAPV_Version, options={"SKIP_SAVE"})
    versions_index: IntProperty(options={"SKIP_SAVE"})
    versions_of: StringProperty(options={"SKIP_SAVE"})


# ---- helpers -------------------------------------------------------------------------------


def project_name_of(scene):
    raw = scene.vista_pictures.project.strip() or (
        pathlib.Path(bpy.data.filepath).stem if bpy.data.filepath else "Blender")
    name = re.sub(r"[^\w .-]", "_", raw, flags=re.UNICODE).strip(" .")[:80]
    return name or "Blender"


def project_name(context):
    return project_name_of(context.scene)


def _client(address, context):
    session = context.window_manager.vista_pictures
    client = transport.VistaClient(address, session.username, session.password)
    if not bpy.app.online_access and not transport.is_local_address(client.base):
        raise transport.BridgeError("Online access is off in Blender's preferences; the bridge only "
                                    "connects to headsets on your local network.")
    return client


def make_clients(context):
    """(name, client) for every headset that is ticked. Raises when there is none to send to."""
    prefs = _prefs()
    chosen = [h for h in prefs.headsets if h.enabled and h.address.strip()]
    if not chosen:
        raise transport.BridgeError(
            "No headset to send to. Press Find, or + and enter the address shown in Vista: "
            "Home > Blender Bridge > START.")
    return [(h.name.strip() or "Quest", _client(h.address, context)) for h in chosen]


def active_client(context):
    """The headset highlighted in the list: the one whose versions the panel shows."""
    prefs = _prefs()
    if not prefs.headsets:
        raise transport.BridgeError("Add a headset first: press Find, or + and enter its address.")
    headset = prefs.headsets[min(max(prefs.active_headset, 0), len(prefs.headsets) - 1)]
    if not headset.address.strip():
        raise transport.BridgeError("Enter the address shown in Vista for %s." % (headset.name or "the headset"))
    return headset.name.strip() or "Quest", _client(headset.address, context)


def _stem(context):
    before = bpy.data.filepath
    base = re.sub(r"[^\w.-]", "_", pathlib.Path(before).stem if before else "Scene")[:60]
    # Sortable by name, so the headset pages through versions oldest to newest.
    return "%s-%s" % (base, time.strftime("%Y%m%d-%H%M%S"))


def snapshot_scene(context, directory):
    """Saves a copy of the open scene for the background export, plus the export's options.

    A copy, never a save: the user's file, its path and its dirty state are left exactly as
    they were, which is what makes it safe to send in the middle of work.
    """
    settings = context.scene.vista_pictures
    if settings.scope == "VARIANTS" and settings.variants is None:
        raise transport.BridgeError("Choose the collection whose sub-collections are the variants.")
    folder = pathlib.Path(directory)
    snapshot = folder / "scene.blend"
    before = bpy.data.filepath
    result = bpy.ops.wm.save_as_mainfile(filepath=str(snapshot), copy=True,
                                         relative_remap=True, check_existing=False)
    if "FINISHED" not in result or bpy.data.filepath != before:
        raise transport.BridgeError("Could not make a copy of the scene to export")
    stem = _stem(context)
    options = {
        "scope": settings.scope,
        "variantsCollection": settings.variants.name if settings.variants is not None else "",
        "animations": settings.animations,
        "animationMode": settings.animation_mode,
        "environment": settings.environment,
        "bake": settings.bake,
        "bakeSize": int(settings.bake_size),
        "cameras": settings.cameras,
        "lights": settings.lights,
        "note": settings.note.strip(),
        "stem": stem,
        "source": pathlib.Path(before).name if before else "",
    }
    (folder / "options.json").write_text(json.dumps(options), encoding="utf-8")
    return folder, snapshot, stem


def save_render(context, directory):
    """Writes the last render to a file as the user sees it, and returns (path, name).

    Through the scene's own colour management — the picture on the headset is the picture in
    Blender's render window — but always as a JPEG, or a PNG when the film is transparent,
    whatever the scene's output is set to: a headset has no use for an EXR sequence setting.
    The settings are put back before this returns.
    """
    image = bpy.data.images.get("Render Result")
    if image is None:
        raise transport.BridgeError("Render the scene first (F12); there is no render to send.")
    scene = context.scene
    settings = scene.render.image_settings
    transparent = bool(scene.render.film_transparent)
    stereo = bool(scene.render.use_multiview)
    names = [n for n in ("media_type", "file_format", "color_mode", "color_depth", "quality", "views_format")
             if hasattr(settings, n)]
    saved = [(n, getattr(settings, n)) for n in names]
    stereo_mode = settings.stereo_3d_format.display_mode
    stereo_squeezed = settings.stereo_3d_format.use_squeezed_frame
    extension = ".png" if transparent else ".jpg"
    name = _stem(context) + extension
    path = pathlib.Path(directory) / name
    try:
        if hasattr(settings, "media_type"):
            settings.media_type = "IMAGE"
        settings.file_format = "PNG" if transparent else "JPEG"
        settings.color_mode = "RGBA" if transparent else "RGB"
        settings.color_depth = "8"
        if not transparent:
            settings.quality = 92
        if stereo:
            # Both eyes in one picture, one above the other, full size: the layout Vista
            # recognises by its shape and shows in depth.
            settings.views_format = "STEREO_3D"
            settings.stereo_3d_format.display_mode = "TOPBOTTOM"
            settings.stereo_3d_format.use_squeezed_frame = False
        image.save_render(str(path), scene=scene)
    except RuntimeError:
        raise transport.BridgeError("Render the scene first (F12); there is no render to send.") from None
    finally:
        for attribute, value in saved:
            try:
                setattr(settings, attribute, value)
            except (TypeError, AttributeError):
                pass
        settings.stereo_3d_format.display_mode = stereo_mode
        settings.stereo_3d_format.use_squeezed_frame = stereo_squeezed
    if not path.is_file() or path.stat().st_size == 0:
        raise transport.BridgeError("Render the scene first (F12); there is no render to send.")
    return path, name


def _redraw(context):
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _wrap(text, width):
    words, lines, line = text.split(), [], ""
    for word in words:
        if line and len(line) + 1 + len(word) > width:
            lines.append(line)
            line = word
        else:
            line = (line + " " + word).strip()
    if line:
        lines.append(line)
    return lines[:6]


def _megabytes(count):
    return "%.0f MB" % (count / 1048576) if count >= 10 * 1048576 else "%.1f MB" % (count / 1048576)


# ---- headsets ------------------------------------------------------------------------------


class VISTAPV_UL_headsets(bpy.types.UIList):
    def draw_item(self, _context, layout, _data, item, _icon, _active_data, _active_propname, _index):
        row = layout.row(align=True)
        row.prop(item, "enabled", text="")
        row.prop(item, "name", text="", emboss=False)
        row.prop(item, "address", text="", emboss=False)


def _normalised(address):
    """An address in the one spelling discovery reports it in, or None when it is not one."""
    try:
        return transport.normalise_address(address)
    except transport.BridgeError:
        return None


def _draw_headsets(layout, prefs):
    row = layout.row()
    row.template_list("VISTAPV_UL_headsets", "", prefs, "headsets", prefs, "active_headset", rows=2)
    column = row.column(align=True)
    column.operator(VISTAPV_OT_find.bl_idname, text="", icon="VIEWZOOM")
    column.operator(VISTAPV_OT_headset_add.bl_idname, text="", icon="ADD")
    column.operator(VISTAPV_OT_headset_remove.bl_idname, text="", icon="REMOVE")
    column.operator(VISTAPV_OT_test.bl_idname, text="", icon="LINKED")


class VISTAPV_OT_find(bpy.types.Operator):
    bl_idname = "vista_pictures.find_headsets"
    bl_label = "Find Headsets"
    bl_description = ("Look for headsets on your local network with Vista's server running "
                      "(Home > Blender Bridge > START)")

    def execute(self, context):
        prefs = _prefs()
        session = context.window_manager.vista_pictures
        found = transport.discover()
        answered = {entry["address"] for entry in found}
        listed = {_normalised(h.address) for h in prefs.headsets}
        added = 0
        for entry in found:
            if entry["address"] in listed:
                continue
            # A headset keeps its name when the router hands it a new address. Found again
            # under one, it takes over its old line in the list rather than sitting beside it.
            moved = next((h for h in prefs.headsets
                          if h.name == entry["name"] and _normalised(h.address) not in answered), None)
            headset = moved or prefs.headsets.add()
            headset.name = entry["name"]
            headset.address = entry["address"]
            added += 1
        if not found:
            session.status = ("No headset answered. Start the server in Vista (Home > Blender Bridge > START) "
                              "and check that the PC and Quest are on the same network.")
            self.report({"WARNING"}, session.status)
            return {"CANCELLED"}
        session.status = "Found %d headset%s%s." % (
            len(found), "" if len(found) == 1 else "s", ", %d new" % added if added else "")
        self.report({"INFO"}, session.status)
        _redraw(context)
        return {"FINISHED"}


class VISTAPV_OT_headset_add(bpy.types.Operator):
    bl_idname = "vista_pictures.headset_add"
    bl_label = "Add Headset"
    bl_description = "Add a headset by typing the address shown in Vista: Home > Blender Bridge > START"

    def execute(self, _context):
        prefs = _prefs()
        prefs.headsets.add()
        prefs.active_headset = len(prefs.headsets) - 1
        return {"FINISHED"}


class VISTAPV_OT_headset_remove(bpy.types.Operator):
    bl_idname = "vista_pictures.headset_remove"
    bl_label = "Remove Headset"
    bl_description = "Remove the highlighted headset from the list"

    @classmethod
    def poll(cls, _context):
        return len(_prefs().headsets) > 0

    def execute(self, _context):
        prefs = _prefs()
        prefs.headsets.remove(min(prefs.active_headset, len(prefs.headsets) - 1))
        prefs.active_headset = max(0, min(prefs.active_headset, len(prefs.headsets) - 1))
        return {"FINISHED"}


class VISTAPV_OT_test(bpy.types.Operator):
    bl_idname = "vista_pictures.test_connection"
    bl_label = "Test Connection"
    bl_description = "Check that Vista Pictures VR is reachable on the highlighted headset"

    def execute(self, context):
        session = context.window_manager.vista_pictures
        try:
            name, client = active_client(context)
            info = client.info()
        except (transport.BridgeError, ConnectionError) as error:
            session.status = str(error)
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}
        free = info.get("freeBytes", 0) / (1024 ** 3)
        session.status = "%s: connected to %s. %.1f GB free." % (name, info.get("app", "Vista"), free)
        self.report({"INFO"}, session.status)
        return {"FINISHED"}


# ---- sending -------------------------------------------------------------------------------


class _Sending:
    """What "Send to Quest" and "Send Render" share: one worker, a modal that shows its progress.

    One send at a time across both: they write to the same status line and the same headsets.
    """
    running = False

    def _start(self, context, job, first_status):
        session = context.window_manager.vista_pictures
        self._thread = threading.Thread(target=job.run, daemon=True)
        _Sending.running = True
        session.busy = True
        session.progress = 0.0
        session.status = first_status
        self._thread.start()
        self._timer = context.window_manager.event_timer_add(0.2, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def _fail(self, context, error):
        session = context.window_manager.vista_pictures
        self._cleanup()
        session.status = str(error)
        self.report({"ERROR"}, str(error))
        return {"CANCELLED"}

    def modal(self, context, event):
        session = context.window_manager.vista_pictures
        if event.type == "ESC" and event.value == "PRESS":
            self._cancel.set()
            session.status = "Cancelling…"
        if event.type != "TIMER":
            return {"PASS_THROUGH"}
        while not self._messages.empty():
            kind, text, extra = self._messages.get_nowait()
            if kind == "progress":
                session.status, session.progress = text, extra
            elif kind == "status":
                session.status = text
            else:
                return self._finish(context, kind, text, extra)
        _redraw(context)
        return {"PASS_THROUGH"}

    def _finish(self, context, kind, text, warnings):
        session = context.window_manager.vista_pictures
        context.window_manager.event_timer_remove(self._timer)
        self._thread.join(2)
        self._cleanup()
        _Sending.running = False
        session.busy = False
        session.progress = 1.0 if kind == "done" else 0.0
        session.status = text
        if kind == "done":
            self.report({"INFO"}, text)
            for warning in warnings or []:
                self.report({"WARNING"}, warning)
            if warnings:
                session.status = text + ". " + warnings[0]
            self._sent(context)
        else:
            self.report({"ERROR"}, text)
        _redraw(context)
        return {"FINISHED"} if kind == "done" else {"CANCELLED"}

    def _sent(self, context):
        """After a send that worked."""

    def _cleanup(self):
        temp = getattr(self, "_temp", None)
        if temp is not None:
            try:
                temp.cleanup()
            except OSError:
                pass
            self._temp = None


class VISTAPV_OT_send(_Sending, bpy.types.Operator):
    bl_idname = "vista_pictures.send"
    bl_label = "Send to Quest"
    bl_description = "Send a copy of the scene to Vista Pictures VR. The open file is not changed"

    @classmethod
    def poll(cls, _context):
        return not _Sending.running

    def invoke(self, context, _event):
        return self.execute(context)

    def execute(self, context):
        try:
            headsets = make_clients(context)
            self._temp = tempfile.TemporaryDirectory(prefix="vista-pictures-")
            folder, snapshot, stem = snapshot_scene(context, self._temp.name)
        except (transport.BridgeError, ConnectionError, OSError) as error:
            return self._fail(context, error)

        self._messages = queue.Queue()
        self._cancel = threading.Event()
        job = pipeline.Job(bpy.app.binary_path, folder, snapshot, stem, project_name(context), headsets,
                           lambda kind, text, extra: self._messages.put((kind, text, extra)), self._cancel)
        return self._start(context, job, "Exporting…")

    def _sent(self, context):
        # The note named THAT version; the next one starts unnamed rather than inheriting it.
        context.scene.vista_pictures.note = ""


class VISTAPV_OT_send_render(_Sending, bpy.types.Operator):
    bl_idname = "vista_pictures.send_render"
    bl_label = "Send Render"
    bl_description = ("Send the last render (F12) to Vista Pictures VR, as you see it. A 360 "
                      "panorama or a stereo render is shown as one on the headset")

    @classmethod
    def poll(cls, _context):
        return not _Sending.running

    def invoke(self, context, _event):
        return self.execute(context)

    def execute(self, context):
        try:
            headsets = make_clients(context)
            self._temp = tempfile.TemporaryDirectory(prefix="vista-pictures-")
            path, name = save_render(context, self._temp.name)
        except (transport.BridgeError, ConnectionError, OSError) as error:
            return self._fail(context, error)

        self._messages = queue.Queue()
        self._cancel = threading.Event()
        job = pipeline.RenderJob(path, name, project_name(context), headsets,
                                 lambda kind, text, extra: self._messages.put((kind, text, extra)), self._cancel)
        return self._start(context, job, "Sending render…")


# ---- check ---------------------------------------------------------------------------------


class VISTAPV_OT_check(bpy.types.Operator):
    bl_idname = "vista_pictures.check"
    bl_label = "Check Scene"
    bl_description = "Count what would be sent and list what will not look in VR as it does here"

    def execute(self, context):
        settings = context.scene.vista_pictures
        session = context.window_manager.vista_pictures
        options = {"bake": settings.bake, "environment": settings.environment,
                   "lights": settings.lights, "cameras": settings.cameras}
        lines = scene_check.inspect(context, settings.scope == "SELECTION", options)
        if settings.scope == "VARIANTS":
            parent = settings.variants
            count = len(parent.children) if parent is not None else 0
            if count < 2:
                lines.insert(0, ("ERROR", "Variants need a collection with at least two sub-collections"))
            else:
                lines.insert(0, ("OK", "%d variants in %s; the numbers below are for all of them shown together"
                                 % (count, parent.name)))
        session.check.clear()
        for level, text in lines:
            line = session.check.add()
            line.level, line.text = level, text
        worst = "ERROR" if any(l == "ERROR" for l, _ in lines) else "WARN" if any(l == "WARN" for l, _ in lines) else "OK"
        self.report({"ERROR": {"ERROR"}, "WARN": {"WARNING"}, "OK": {"INFO"}}[worst],
                    {"ERROR": "This scene cannot be sent as it is", "WARN": "Ready, with notes",
                     "OK": "Ready to send"}[worst])
        return {"FINISHED"}


# ---- versions ------------------------------------------------------------------------------


def _load_versions(context):
    session = context.window_manager.vista_pictures
    project = project_name(context)
    _name, client = active_client(context)
    listed = client.versions(project)
    session.versions.clear()
    # Newest first: the version just sent is the one most often wanted.
    for entry in reversed(listed):
        item = session.versions.add()
        item.file = str(entry.get("file", ""))
        item.kind = str(entry.get("kind", "model"))
        note = str(entry.get("note", "")).strip()
        variant = str(entry.get("variant", "")).strip()
        when = time.strftime("%d %b %H:%M", time.localtime(float(entry.get("modified", 0)) / 1000.0))
        item.label = " · ".join(p for p in (variant, note) if p) or item.file.rsplit("/", 1)[-1]
        item.detail = "%s  %s" % (when, _megabytes(float(entry.get("bytes", 0))))
    session.versions_index = 0
    session.versions_of = project
    return len(listed)


class VISTAPV_UL_versions(bpy.types.UIList):
    def draw_item(self, _context, layout, _data, item, _icon, _active_data, _active_propname, _index):
        row = layout.row(align=True)
        row.label(text=item.label, icon="IMAGE_DATA" if item.kind == "render" else "MESH_CUBE")
        sub = row.row()
        sub.alignment = "RIGHT"
        sub.label(text=item.detail)


class _VersionOperator:
    @classmethod
    def poll(cls, context):
        session = context.window_manager.vista_pictures
        return 0 <= session.versions_index < len(session.versions)

    def _chosen(self, context):
        session = context.window_manager.vista_pictures
        return session.versions[session.versions_index]

    def _run(self, context, action, done):
        session = context.window_manager.vista_pictures
        try:
            _name, client = active_client(context)
            action(client, session.versions_of or project_name(context))
            _load_versions(context)
        except (transport.BridgeError, ConnectionError) as error:
            session.status = str(error)
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}
        session.status = done
        self.report({"INFO"}, done)
        _redraw(context)
        return {"FINISHED"}


class VISTAPV_OT_versions_refresh(bpy.types.Operator):
    bl_idname = "vista_pictures.versions_refresh"
    bl_label = "Refresh"
    bl_description = "List this project's versions on the highlighted headset"

    def execute(self, context):
        session = context.window_manager.vista_pictures
        try:
            count = _load_versions(context)
        except (transport.BridgeError, ConnectionError) as error:
            session.status = str(error)
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}
        self.report({"INFO"}, "%d on the headset" % count)
        return {"FINISHED"}


class VISTAPV_OT_version_show(_VersionOperator, bpy.types.Operator):
    bl_idname = "vista_pictures.version_show"
    bl_label = "Show on Quest"
    bl_description = "Show this version on the headset, as if it had just been sent"

    def execute(self, context):
        chosen = self._chosen(context).file
        return self._run(context, lambda client, project: client.show(project, chosen),
                         "Asked the Quest to show %s" % chosen)


class VISTAPV_OT_version_note(_VersionOperator, bpy.types.Operator):
    bl_idname = "vista_pictures.version_note"
    bl_label = "Name Version"
    bl_description = "Give this version a name or a note. Shown here and on the headset"

    note: StringProperty(name="Note", maxlen=200)

    @classmethod
    def poll(cls, context):
        session = context.window_manager.vista_pictures
        return (0 <= session.versions_index < len(session.versions)
                and session.versions[session.versions_index].kind != "render")

    def invoke(self, context, _event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        chosen = self._chosen(context).file
        note = self.note
        return self._run(context, lambda client, project: client.set_note(project, chosen, note),
                         "Named %s" % chosen)


class VISTAPV_OT_version_delete(_VersionOperator, bpy.types.Operator):
    bl_idname = "vista_pictures.version_delete"
    bl_label = "Delete this version from the Quest?"
    bl_description = "Delete this version from the headset. This cannot be undone"

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        chosen = self._chosen(context).file
        return self._run(context, lambda client, project: client.delete_version(project, chosen),
                         "Deleted %s from the Quest" % chosen)


class VISTAPV_OT_versions_prune(bpy.types.Operator):
    bl_idname = "vista_pictures.versions_prune"
    bl_label = "Delete Older Versions"
    bl_description = "Delete all but the newest models of this project from the headset. Renders are kept"

    keep: IntProperty(name="Keep the newest", default=3, min=1, max=50)

    @classmethod
    def poll(cls, context):
        return len(context.window_manager.vista_pictures.versions) > 1

    def invoke(self, context, _event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        session = context.window_manager.vista_pictures
        try:
            _name, client = active_client(context)
            project = session.versions_of or project_name(context)
            # Asked again rather than trusted from the panel: the list there may be minutes old.
            models = [v["file"] for v in client.versions(project) if v.get("kind") != "render"]
            doomed = models[:-self.keep] if len(models) > self.keep else []
            freed = 0
            for name in doomed:
                freed += int(client.delete_version(project, name).get("freedBytes", 0))
            _load_versions(context)
        except (transport.BridgeError, ConnectionError) as error:
            session.status = str(error)
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}
        session.status = "Deleted %d older versions, %s freed" % (len(doomed), _megabytes(freed))
        self.report({"INFO"}, session.status)
        _redraw(context)
        return {"FINISHED"}


# ---- panels --------------------------------------------------------------------------------


class _VistaPanel:
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Vista"


class VISTAPV_PT_bridge(_VistaPanel, bpy.types.Panel):
    bl_label = "Vista Pictures VR"
    bl_idname = "VISTAPV_PT_bridge"

    def draw(self, context):
        layout = self.layout
        prefs = _prefs()
        settings = context.scene.vista_pictures
        session = context.window_manager.vista_pictures

        _draw_headsets(layout, prefs)
        if not prefs.headsets:
            layout.label(text="In Vista: Home > Blender Bridge > START", icon="INFO")
            layout.operator(VISTAPV_OT_find.bl_idname, icon="VIEWZOOM")

        layout.prop(settings, "project", placeholder=project_name(context))
        layout.row().prop(settings, "scope", expand=True)
        if settings.scope == "VARIANTS":
            layout.prop(settings, "variants")

        ready = not session.busy and any(h.enabled and h.address.strip() for h in prefs.headsets)
        col = layout.column()
        col.scale_y = 1.5
        col.enabled = ready
        col.operator(VISTAPV_OT_send.bl_idname, icon="EXPORT")
        row = layout.row()
        row.enabled = ready
        row.operator(VISTAPV_OT_send_render.bl_idname, icon="RENDER_STILL")
        row = layout.row(align=True)
        row.prop(prefs, "send_on_save")
        row.prop(prefs, "sync_timeline")

        if session.busy:
            layout.progress(factor=session.progress, text=session.status or "Working…")
            layout.label(text="Esc cancels", icon="CANCEL")
        elif session.status:
            box = layout.box()
            for line in _wrap(session.status, 38):
                box.label(text=line)


class VISTAPV_PT_content(_VistaPanel, bpy.types.Panel):
    bl_label = "What Is Sent"
    bl_parent_id = "VISTAPV_PT_bridge"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.vista_pictures
        layout.prop(settings, "note")
        row = layout.row(align=True)
        row.prop(settings, "animations", toggle=True)
        row.prop(settings, "environment", toggle=True)
        row = layout.row(align=True)
        row.prop(settings, "cameras", toggle=True)
        row.prop(settings, "lights", toggle=True)
        if settings.animations:
            layout.prop(settings, "animation_mode")
        row = layout.row(align=True)
        row.prop(settings, "bake")
        sub = row.row()
        sub.enabled = settings.bake
        sub.prop(settings, "bake_size", text="")


class VISTAPV_PT_check(_VistaPanel, bpy.types.Panel):
    bl_label = "Check Scene"
    bl_parent_id = "VISTAPV_PT_bridge"
    bl_options = {"DEFAULT_CLOSED"}

    _ICONS = {"ERROR": "CANCEL", "WARN": "ERROR", "INFO": "INFO", "OK": "CHECKMARK"}

    def draw(self, context):
        layout = self.layout
        session = context.window_manager.vista_pictures
        layout.operator(VISTAPV_OT_check.bl_idname, icon="VIEWZOOM")
        for line in session.check:
            wrapped = _wrap(line.text, 36)
            for index, text in enumerate(wrapped):
                layout.label(text=text, icon=self._ICONS.get(line.level, "INFO") if index == 0 else "BLANK1")


class VISTAPV_PT_versions(_VistaPanel, bpy.types.Panel):
    bl_label = "Versions on the Quest"
    bl_parent_id = "VISTAPV_PT_bridge"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        session = context.window_manager.vista_pictures
        row = layout.row(align=True)
        row.operator(VISTAPV_OT_versions_refresh.bl_idname, icon="FILE_REFRESH")
        row.operator(VISTAPV_OT_versions_prune.bl_idname, text="", icon="TRASH")
        if session.versions_of:
            layout.label(text="Project: " + session.versions_of)
        layout.template_list("VISTAPV_UL_versions", "", session, "versions", session, "versions_index", rows=4)
        row = layout.row(align=True)
        row.operator(VISTAPV_OT_version_show.bl_idname, icon="HIDE_OFF")
        row.operator(VISTAPV_OT_version_note.bl_idname, text="", icon="GREASEPENCIL")
        row.operator(VISTAPV_OT_version_delete.bl_idname, text="", icon="X")


class VISTAPV_PT_login(_VistaPanel, bpy.types.Panel):
    bl_label = "Password"
    bl_parent_id = "VISTAPV_PT_bridge"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        session = context.window_manager.vista_pictures
        self.layout.label(text="Only if enabled in Vista's server screen")
        self.layout.prop(session, "username")
        self.layout.prop(session, "password")


# ---- handlers ------------------------------------------------------------------------------


@persistent
def _send_after_save(*_args):
    try:
        prefs = _prefs()
    except (KeyError, AttributeError):
        return
    if not prefs.send_on_save or _Sending.running:
        return
    if not any(h.enabled and h.address.strip() for h in prefs.headsets):
        return
    # Not from inside the save handler itself: the save is still finishing, and an operator
    # that saves a copy of the file must not run in the middle of a save.
    bpy.app.timers.register(_send_from_timer, first_interval=0.2)


def _send_from_timer():
    wm = bpy.context.window_manager
    window = wm.windows[0] if wm.windows else None
    if window is None or _Sending.running:
        return None
    area = next((a for a in window.screen.areas if a.type == "VIEW_3D"), None)
    with bpy.context.temp_override(window=window, area=area):
        bpy.ops.vista_pictures.send("INVOKE_DEFAULT")
    return None


_sync = timeline.TimelineSync()
# Whether an address is on the local network, remembered: finding out can mean a name lookup,
# and the frame-change handler below has no time for one.
_local = {}


def _timeline_headsets(prefs):
    wm = bpy.context.window_manager
    session = getattr(wm, "vista_pictures", None) if wm is not None else None
    username = session.username if session is not None else ""
    password = session.password if session is not None else ""
    result = []
    for headset in prefs.headsets:
        address = headset.address.strip()
        if not headset.enabled or not address:
            continue
        if address not in _local:
            try:
                _local[address] = transport.is_local_address(transport.normalise_address(address))
            except transport.BridgeError:
                _local[address] = False
        if _local[address] or bpy.app.online_access:
            result.append((address, username, password))
    return result


def _push_timeline(scene, playing):
    try:
        prefs = _prefs()
    except (KeyError, AttributeError):
        return
    if not prefs.sync_timeline or scene is None or not hasattr(scene, "vista_pictures"):
        return
    # A render steps the frame too, and the headset has no business following that.
    if bpy.app.is_job_running("RENDER"):
        return
    headsets = _timeline_headsets(prefs)
    if not headsets:
        return
    fps = scene.render.fps / scene.render.fps_base
    # frame / fps is the clock Blender's glTF exporter writes keyframes on, so the headset can
    # use the number as it is.
    _sync.push(headsets, project_name_of(scene), max(0.0, scene.frame_current_final / fps), playing)


@persistent
def _frame_changed(scene, *_args):
    screen = bpy.context.screen
    _push_timeline(scene, bool(screen is not None and screen.is_animation_playing))


@persistent
def _playback_stopped(scene, *_args):
    # Without this the headset would play on after Blender stopped: the last frame change it
    # heard of still said "playing".
    _push_timeline(scene, False)


# ---- registration --------------------------------------------------------------------------


_classes = (
    VISTAPV_Headset, VISTAPV_Preferences, VISTAPV_SceneSettings, VISTAPV_CheckLine, VISTAPV_Version,
    VISTAPV_Session, VISTAPV_UL_headsets, VISTAPV_UL_versions,
    VISTAPV_OT_find, VISTAPV_OT_headset_add, VISTAPV_OT_headset_remove, VISTAPV_OT_test,
    VISTAPV_OT_send, VISTAPV_OT_send_render, VISTAPV_OT_check,
    VISTAPV_OT_versions_refresh, VISTAPV_OT_version_show, VISTAPV_OT_version_note,
    VISTAPV_OT_version_delete, VISTAPV_OT_versions_prune,
    VISTAPV_PT_bridge, VISTAPV_PT_content, VISTAPV_PT_check, VISTAPV_PT_versions, VISTAPV_PT_login,
)

_handlers = (
    ("save_post", _send_after_save),
    ("frame_change_post", _frame_changed),
    ("animation_playback_post", _playback_stopped),
)


def _adopt_old_address():
    """Version 1.0 had one address field; it becomes the first headset of the list."""
    try:
        prefs = _prefs()
    except (KeyError, AttributeError):
        return
    if prefs.address.strip() and not prefs.headsets:
        headset = prefs.headsets.add()
        headset.address = prefs.address.strip()
    prefs.address = ""


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.vista_pictures = PointerProperty(type=VISTAPV_SceneSettings)
    bpy.types.WindowManager.vista_pictures = PointerProperty(type=VISTAPV_Session)
    for name, handler in _handlers:
        handlers = getattr(bpy.app.handlers, name)
        if handler not in handlers:
            handlers.append(handler)
    _adopt_old_address()


def unregister():
    for name, handler in _handlers:
        handlers = getattr(bpy.app.handlers, name)
        if handler in handlers:
            handlers.remove(handler)
    del bpy.types.WindowManager.vista_pictures
    del bpy.types.Scene.vista_pictures
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
