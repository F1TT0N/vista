# SPDX-License-Identifier: GPL-3.0-or-later
"""Talks to the transfer server inside Vista Pictures VR on the Quest.

Plain urllib on purpose: Blender ships no third-party HTTP client, and an add-on that bundles
one has to vendor it for every platform. The protocol is small enough not to need one.

Every chunk is confirmed by the server with the offset it now holds, so a dropped connection
is resumed from where the headset actually is rather than from where we hoped it was.
"""
import base64
import ipaddress
import json
import pathlib
import select
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

CHUNK_BYTES = 4 * 1024 * 1024
RETRIES = 3
TIMEOUT = 30
# Where Vista answers "is there a headset here?" (BridgeBeacon.DEFAULT_PORT on the other side).
DISCOVERY_PORT = 22096
DISCOVERY_QUERY = b"VISTA-DISCOVER 1"


class BridgeError(Exception):
    """A failure worth showing to the user as it is."""


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def normalise_address(address):
    """Accepts "192.168.1.28", "192.168.1.28:8080" or the full URL the headset shows."""
    text = address.strip().rstrip("/")
    if not text:
        raise BridgeError("Enter the address shown in Vista: Home > Blender Bridge > START")
    if "://" not in text:
        text = "http://" + text
    parsed = urllib.parse.urlsplit(text)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise BridgeError("Enter the address shown in Vista (Home > Blender Bridge > START), e.g. http://192.168.1.28:8080")
    if parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in {"", "/"}:
        raise BridgeError("Enter only the address, e.g. http://192.168.1.28:8080")
    port = parsed.port or (8080 if parsed.scheme == "http" else 443)
    host = parsed.hostname
    netloc = ("[%s]" % host if ":" in host else host) + ":" + str(port)
    return urllib.parse.urlunsplit((parsed.scheme, netloc, "", "", ""))


def is_local_address(address):
    """True for loopback and private-network hosts — the only places the headset can be."""
    host = urllib.parse.urlsplit(address).hostname or ""
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        try:
            ip = ipaddress.ip_address(socket.gethostbyname(host))
        except (OSError, ValueError):
            return host.endswith(".local")
    return ip.is_private or ip.is_loopback or ip.is_link_local


class VistaClient:
    def __init__(self, address, username="", password=""):
        self.base = normalise_address(address)
        self._features = None
        self.headers = {}
        if username or password:
            token = base64.b64encode((username + ":" + password).encode()).decode()
            self.headers["Authorization"] = "Basic " + token
        self.opener = urllib.request.build_opener(_NoRedirect())

    # -- plumbing ---------------------------------------------------------------------------

    def request(self, method, path, body=None, content_type="application/json", timeout=TIMEOUT):
        if isinstance(body, dict):
            body = json.dumps(body, ensure_ascii=False).encode()
        headers = dict(self.headers)
        if body is not None:
            headers["Content-Type"] = content_type
        req = urllib.request.Request(self.base + path, data=body, method=method, headers=headers)
        try:
            with self.opener.open(req, timeout=timeout) as response:
                raw = response.read(1024 * 1024 + 1)
        except urllib.error.HTTPError as error:
            raise BridgeError(self._explain(error)) from None
        except (urllib.error.URLError, socket.timeout, ConnectionError) as error:
            raise ConnectionError(self._unreachable(error)) from None
        if len(raw) > 1024 * 1024:
            raise BridgeError("The headset sent an unexpectedly large reply")
        try:
            return json.loads(raw) if raw else {}
        except ValueError:
            raise BridgeError("That address answered, but it is not Vista Pictures VR's bridge. "
                              "Update Vista on the Quest, or check the address.") from None

    def _explain(self, error):
        try:
            message = json.loads(error.read(65536) or b"{}").get("error", "")
        except ValueError:
            message = ""
        if error.code == 401:
            return "The headset asked for a password. Enter the one set in Vista's server screen."
        if error.code == 404:
            return "This Vista version has no Blender bridge yet. Update Vista on the Quest."
        return message or "The headset refused the request (HTTP %d)" % error.code

    def _unreachable(self, error):
        return ("Cannot reach %s. Check that the server is running in Vista (Home > Blender Bridge > "                "START), that the address matches, and that the PC and Quest are on the same network "
                "(guest Wi-Fi usually keeps devices apart). [%s]" % (self.base, getattr(error, "reason", error)))

    # -- API -------------------------------------------------------------------------------

    def info(self):
        """What is at the other end. Raises BridgeError if it is not a Vista bridge."""
        info = self.request("GET", "/api/bridge", timeout=8)
        if "bridge" not in info:
            raise BridgeError("That address answered, but it is not Vista Pictures VR's bridge.")
        return info

    def features(self):
        """What this Vista can do beyond receiving a scene. Empty for a Vista that predates them."""
        if self._features is None:
            self._features = frozenset(str(f) for f in self.info().get("features", []))
        return self._features

    def require(self, feature, what):
        if feature not in self.features():
            raise BridgeError("%s needs a newer Vista Pictures VR on the Quest. Update it there." % what)

    def versions(self, project):
        """The versions of a project on the headset, oldest first, renders after models."""
        self.require("versions", "Listing versions")
        query = urllib.parse.urlencode({"project": project})
        return self.request("GET", "/api/bridge/versions?" + query, timeout=10).get("versions", [])

    def delete_version(self, project, name):
        self.require("versions", "Deleting a version")
        query = urllib.parse.urlencode({"project": project, "file": name})
        return self.request("DELETE", "/api/bridge/versions?" + query, timeout=15)

    def set_note(self, project, name, note):
        self.require("versions", "Naming a version")
        return self.request("POST", "/api/bridge/note", {"project": project, "file": name, "note": note}, timeout=10)

    def show(self, project, name):
        """Asks the headset to show a version it already has."""
        self.require("show", "Showing a version")
        return self.request("POST", "/api/bridge/show", {"project": project, "file": name}, timeout=10)

    def timeline(self, project, seconds, playing):
        """Where Blender's playhead is. Short timeout: a late position is worth nothing."""
        return self.request("POST", "/api/bridge/timeline",
                            {"project": project, "time": round(float(seconds), 4), "playing": bool(playing)},
                            timeout=2)

    def exists(self, destination, size):
        query = urllib.parse.urlencode({"path": destination, "size": size})
        try:
            return bool(self.request("GET", "/api/bridge/exists?" + query).get("exists"))
        except BridgeError:
            return False

    def upload(self, source, destination, cancelled=lambda: False, progress=lambda done, total: None):
        source = pathlib.Path(source)
        total = source.stat().st_size
        parts = destination.split("/")
        if len(parts) < 2 or any(not p or p.startswith(".") or "\\" in p or ":" in p for p in parts):
            raise BridgeError("Invalid destination " + destination)
        created = self.request("POST", "/api/uploads", {"path": destination, "total": total})
        identifier = created.get("id")
        if not isinstance(identifier, str) or not all(c.isalnum() or c in "-_" for c in identifier):
            raise BridgeError("The headset returned an invalid upload id")
        complete = False
        try:
            with source.open("rb") as stream:
                offset = 0
                failures = 0
                while True:
                    if cancelled():
                        raise InterruptedError("Cancelled")
                    stream.seek(offset)
                    chunk = stream.read(CHUNK_BYTES)
                    done = offset + len(chunk) == total
                    if not chunk and not done:
                        raise BridgeError("The export changed while it was being sent")
                    try:
                        result = self._send_chunk(identifier, offset, chunk, done)
                    except ConnectionError:
                        failures += 1
                        if failures > RETRIES:
                            raise
                        # Ask where the headset really is; the chunk may or may not have landed.
                        offset = int(self.request("GET", "/api/uploads/" + identifier).get("offset", offset))
                        continue
                    failures = 0
                    new_offset = result.get("offset")
                    if new_offset != offset + len(chunk):
                        raise BridgeError("The headset did not confirm the bytes it received")
                    offset = new_offset
                    progress(offset, total)
                    if done:
                        if result.get("status") != "complete":
                            raise BridgeError("The headset did not finish saving " + source.name)
                        complete = True
                        return result
        finally:
            if not complete:
                try:
                    self.request("DELETE", "/api/uploads/" + identifier, timeout=5)
                except Exception:
                    pass

    def _send_chunk(self, identifier, offset, chunk, done):
        boundary = "vista-" + uuid.uuid4().hex
        body = (("--" + boundary + '\r\nContent-Disposition: form-data; name="file"; filename="chunk.bin"\r\n'
                 "Content-Type: application/octet-stream\r\n\r\n").encode()
                + chunk + ("\r\n--" + boundary + "--\r\n").encode())
        query = urllib.parse.urlencode({"id": identifier, "offset": offset, "done": "true" if done else "false"})
        return self.request("POST", "/upload?" + query, body, "multipart/form-data; boundary=" + boundary)


def local_ipv4_addresses():
    """This PC's own addresses on private networks — the ones a headset could be beside."""
    found = []
    try:
        found += socket.gethostbyname_ex(socket.gethostname())[2]
    except OSError:
        pass
    # The interface the default route uses, which the lookup above can miss on a PC whose host
    # name resolves to a virtual adapter. Connecting a UDP socket sends nothing; it only asks
    # the OS which address it would send from.
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.connect(("192.168.255.255", 9))
            found.append(probe.getsockname()[0])
    except OSError:
        pass
    result = []
    for text in found:
        try:
            ip = ipaddress.ip_address(text)
        except ValueError:
            continue
        if ip.version == 4 and ip.is_private and not ip.is_loopback and text not in result:
            result.append(text)
    return result


def discover(timeout=1.5, port=DISCOVERY_PORT, extra_targets=()):
    """Headsets on the local network with Vista's transfer server running.

    One small UDP packet is broadcast on every local network this PC is on; each headset
    answers the sender directly with where its server is. Nothing is sent beyond the local
    network — a broadcast does not cross a router — and nothing at all unless this is called.

    Returns a list of {"name", "address", "auth"}, nearest answer first.
    """
    sockets = []
    try:
        for local in local_ipv4_addresses() or [""]:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                sock.bind((local, 0))
                sock.setblocking(False)
            except OSError:
                continue
            sockets.append(sock)
            targets = {"255.255.255.255"}
            if local:
                # The network's own broadcast address as well: some routers pass that and
                # drop the all-ones one. /24 is assumed, which is what home networks are.
                targets.add(local.rsplit(".", 1)[0] + ".255")
            targets.update(extra_targets)
            for target in targets:
                try:
                    sock.sendto(DISCOVERY_QUERY, (target, port))
                except OSError:
                    pass
        found = {}
        deadline = time.monotonic() + timeout
        while sockets:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            readable, _, _ = select.select(sockets, [], [], remaining)
            for sock in readable:
                try:
                    data, sender = sock.recvfrom(2048)
                    reply = json.loads(data.decode("utf-8"))
                except (OSError, ValueError):
                    continue
                if not isinstance(reply, dict) or not str(reply.get("app", "")).startswith("Vista"):
                    continue
                try:
                    server_port = int(reply.get("port", 8080))
                except (TypeError, ValueError):
                    continue
                if not 0 < server_port < 65536:
                    continue
                address = "http://%s:%d" % (sender[0], server_port)
                found.setdefault(address, {
                    "name": str(reply.get("name") or "Quest")[:40],
                    "address": address,
                    "auth": bool(reply.get("auth")),
                })
        return list(found.values())
    finally:
        for sock in sockets:
            sock.close()