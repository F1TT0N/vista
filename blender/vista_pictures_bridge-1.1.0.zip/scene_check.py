# SPDX-License-Identifier: GPL-3.0-or-later
"""What is in a scene, as Vista Pictures VR will see it.

Shared by the two places that need the same answers: the panel's "Check scene", which runs in
the user's Blender and only looks, and the export job, which runs in a background Blender on a
copy and acts on what it finds. One module, so the check can never promise something the export
then does differently.
"""
import math

import bpy
from mathutils import Vector

# What Vista Pictures VR can show; a scene over this would fail on the headset with no way to
# fix it from there, so it is refused here with the number in hand.
MAX_TRIANGLES = 2_000_000
# Wider than this is past what the Quest 3 panel resolves and costs gigabytes on the headset.
MAX_ENV_WIDTH = 8192
# Vista's glTF reader downsamples every texture to this edge (GltfParser.MAX_TEXTURE_EDGE).
MAX_TEXTURE_EDGE = 2048
# Vista's glTF reader refuses a model file larger than this (GltfParser.MAX_MODEL_BYTES).
MAX_MODEL_BYTES = 128 * 1024 * 1024
# How many of a scene's lamps Vista shades (MAX_LIGHTS in model_renderer.h).
MAX_LIGHTS = 8
# Morph-target offsets Vista keeps for one model, in floats (GltfParser.MAX_MORPH_FLOATS).
MAX_MORPH_FLOATS = 16 * 1024 * 1024
MODEL_TYPES = {"MESH", "CURVE", "SURFACE", "META", "FONT", "CURVES", "POINTCLOUD"}

# Colour plumbing an image texture may pass through on its way to Base Color and still be
# something the glTF exporter can follow back to the image.
_PASS_THROUGH = {"MIX_RGB", "MIX", "CURVE_RGB", "HUE_SAT", "BRIGHTCONTRAST", "GAMMA", "INVERT",
                 "SEPARATE_COLOR", "RGB_TO_BW", "REROUTE"}


def uses_nodes(datablock):
    """A material or world drawn by its node tree.

    `use_nodes` is deprecated in Blender 5 and gone in 6, where every material and world is
    node-based; reading it only where it still exists keeps one add-on working on both.
    """
    return datablock.node_tree is not None and getattr(datablock, "use_nodes", True)


def included(obj, selection_only):
    if not obj.visible_get():
        return False
    return obj.select_get() if selection_only else True


def model_objects(scene, selection_only):
    return [o for o in scene.objects if o.type in MODEL_TYPES and included(o, selection_only)]


def count_triangles(depsgraph, selection_only):
    """Triangles as they will be exported: modifiers applied, instances expanded."""
    triangles = 0
    objects = set()
    for inst in depsgraph.object_instances:
        owner = (inst.parent if inst.is_instance and inst.parent else inst.object).original
        if not included(owner, selection_only):
            continue
        ob = inst.object
        if ob.type not in MODEL_TYPES:
            continue
        objects.add(owner.name)
        if ob.type == "MESH":
            triangles += sum(len(p.vertices) - 2 for p in ob.data.polygons)
        else:
            try:
                mesh = ob.to_mesh()
                triangles += sum(len(p.vertices) - 2 for p in mesh.polygons)
            except RuntimeError:
                pass
            finally:
                ob.to_mesh_clear()
    return triangles, len(objects)


# ---- materials ---------------------------------------------------------------------------


def ends_in_image(node, depth=0):
    """Image textures, possibly through the usual colour plumbing in between."""
    if node.type == "TEX_IMAGE" and node.image is not None:
        return True
    if depth > 4 or node.type not in _PASS_THROUGH:
        return False
    return any(ends_in_image(link.from_node, depth + 1)
               for inp in node.inputs for link in inp.links)


def classify_material(mat):
    """"plain", "image", "procedural" (a colour glTF cannot carry) or "unsupported" (no Principled)."""
    if mat is None or not uses_nodes(mat):
        return "plain"
    principled = [n for n in mat.node_tree.nodes if n.type == "BSDF_PRINCIPLED"]
    if not principled:
        return "unsupported"
    base = principled[0].inputs.get("Base Color")
    if base is None or not base.is_linked:
        return "plain"
    return "image" if ends_in_image(base.links[0].from_node) else "procedural"


def materials_in_use(scene, selection_only):
    """{material name: class} over every included object."""
    found = {}
    for obj in model_objects(scene, selection_only):
        for slot in obj.material_slots:
            mat = slot.material
            if mat is not None and mat.name not in found:
                found[mat.name] = classify_material(mat)
    return found


def names(items, limit=3):
    items = list(items)
    shown = ", ".join(items[:limit])
    return shown + (" and %d more" % (len(items) - limit) if len(items) > limit else "")


def material_warnings(scene, selection_only, baked=()):
    """Materials that will not look in VR like they do in Blender, and why."""
    classes = materials_in_use(scene, selection_only)
    procedural = [n for n, c in classes.items() if c == "procedural" and n not in baked]
    unsupported = [n for n, c in classes.items() if c == "unsupported" and n not in baked]
    warnings = []
    if procedural:
        warnings.append("Procedural colour in %s: bake it to an image texture to see it in VR"
                        % names(procedural))
    if unsupported:
        warnings.append("No Principled BSDF in %s: shown as a plain surface" % names(unsupported))
    return warnings


def texture_bytes(scene, selection_only):
    """What the scene's colour textures will occupy on the headset, mipmaps included.

    Counted the way Vista loads them: only what feeds Base Color, each image once, capped at
    MAX_TEXTURE_EDGE, four bytes a pixel and a third again for the mip chain.
    """
    seen = set()
    total = 0
    for obj in model_objects(scene, selection_only):
        for slot in obj.material_slots:
            mat = slot.material
            if mat is None or not uses_nodes(mat):
                continue
            for node in mat.node_tree.nodes:
                image = getattr(node, "image", None) if node.type == "TEX_IMAGE" else None
                if image is None or image.name in seen:
                    continue
                seen.add(image.name)
                width, height = image.size[0], image.size[1]
                edge = max(width, height)
                if edge > MAX_TEXTURE_EDGE:
                    width = max(1, round(width * MAX_TEXTURE_EDGE / edge))
                    height = max(1, round(height * MAX_TEXTURE_EDGE / edge))
                total += width * height * 4 * 4 // 3
    return total, len(seen)


# ---- the World ---------------------------------------------------------------------------


def find_environment(world):
    """The Environment Texture that actually feeds the World output, if there is one."""
    if world is None or not uses_nodes(world):
        return None
    nodes = world.node_tree.nodes
    outputs = [n for n in nodes if n.type == "OUTPUT_WORLD"]
    outputs.sort(key=lambda n: not n.is_active_output)
    seen = set()
    stack = list(outputs[:1])
    while stack:
        node = stack.pop()
        if node.name in seen:
            continue
        seen.add(node.name)
        if node.type == "TEX_ENVIRONMENT" and node.image is not None:
            return node
        for inp in node.inputs:
            for link in inp.links:
                stack.append(link.from_node)
    return None


def environment_yaw(node):
    """How Vista has to turn the sky about the vertical so it sits as it does in Blender.

    Returns (radians, tilted). The angle is about glTF's +Y for a sphere whose image centre
    faces -Z, which is how Vista hangs an equirectangular image; measured, not assumed:

    - Blender puts the image's centre on +X, and its left quarter on +Y. Exported Y-up that is
      +X and -Z, where Vista unrotated has the centre on -Z and the left quarter on -X. A
      quarter turn the other way, -90 degrees, lines the two up.
    - A Mapping node in front of the texture turns the LOOKUP, so the sky turns the opposite
      way: by -Z for the Point, Vector and Normal types, and by +Z for Texture, which is the
      inverse transform.

    [tilted] is True when the Mapping also rotates about X or Y, which is not carried over.
    """
    yaw = -math.pi / 2
    tilted = False
    vector = node.inputs.get("Vector")
    if vector is not None and vector.is_linked:
        mapping = vector.links[0].from_node
        if mapping.type == "MAPPING":
            rotation = mapping.inputs["Rotation"].default_value
            yaw += rotation[2] if mapping.vector_type == "TEXTURE" else -rotation[2]
            tilted = abs(rotation[0]) > 1e-4 or abs(rotation[1]) > 1e-4
    # Wrapped to (-pi, pi]: the same turn, and a number someone reading the report can follow.
    yaw = math.atan2(math.sin(yaw), math.cos(yaw))
    return yaw, tilted


def environment_strength(node):
    """The Background node's Strength the sky is plugged into; 1 when it is not found."""
    seen = set()
    stack = [link.to_node for out in node.outputs for link in out.links]
    while stack:
        current = stack.pop()
        if current.name in seen:
            continue
        seen.add(current.name)
        if current.type == "BACKGROUND":
            strength = current.inputs.get("Strength")
            if strength is not None and not strength.is_linked:
                return max(0.0, float(strength.default_value))
            return 1.0
        for out in current.outputs:
            for link in out.links:
                stack.append(link.to_node)
    return 1.0


# ---- cameras and lamps --------------------------------------------------------------------


def to_gltf(vector):
    """Blender's Z-up to glTF's Y-up, the same turn the exporter gives the model."""
    return [round(float(vector[0]), 6), round(float(vector[2]), 6), round(float(-vector[1]), 6)]


def viewpoints(scene):
    """The scene's cameras, as places to stand: the active one first, the rest by name."""
    cameras = [o for o in scene.objects if o.type == "CAMERA" and o.visible_get()]
    cameras.sort(key=lambda o: (o != scene.camera, o.name.lower()))
    result = []
    for cam in cameras[:32]:
        matrix = cam.matrix_world
        forward = (matrix.to_quaternion() @ Vector((0.0, 0.0, -1.0))).normalized()
        result.append({
            "name": cam.name,
            "position": to_gltf(matrix.translation),
            "forward": to_gltf(forward),
        })
    return result


def _blackbody(kelvin):
    """Linear RGB tint of a black body, brightest channel at 1. Tanner Helland's fit."""
    t = max(1000.0, min(40000.0, kelvin)) / 100.0
    if t <= 66:
        r = 255.0
        g = 99.4708025861 * math.log(t) - 161.1195681661
        b = 0.0 if t <= 19 else 138.5177312231 * math.log(t - 10) - 305.0447927307
    else:
        r = 329.698727446 * (t - 60) ** -0.1332047592
        g = 288.1221695283 * (t - 60) ** -0.0755148492
        b = 255.0
    rgb = [max(0.0, min(255.0, c)) / 255.0 for c in (r, g, b)]
    linear = [c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4 for c in rgb]
    peak = max(linear) or 1.0
    return [c / peak for c in linear]


def lights(scene):
    """The scene's lamps in the units Blender renders in, and what could not be carried over.

    Returns (lamps, warnings). A sun's colour is its irradiance (Strength, W/m2). The others
    carry radiant intensity: a point or spot lamp of P watts shines P/4pi per steradian, and an
    area lamp P/4 along its normal falling off with the cosine — which is how Cycles itself
    turns "Power" into light, so a lamp is as bright against the sky in VR as in a render.
    """
    lamps, warnings = [], []
    unnormalised = []
    for obj in scene.objects:
        if obj.type != "LIGHT" or not obj.visible_get() or obj.hide_render:
            continue
        data = obj.data
        energy = float(data.energy) * 2.0 ** float(getattr(data, "exposure", 0.0))
        if energy <= 0.0:
            continue
        colour = [float(c) for c in data.color]
        if getattr(data, "use_temperature", False):
            tint = _blackbody(float(data.temperature))
            colour = [c * t for c, t in zip(colour, tint)]
        if data.type != "SUN" and not getattr(data, "normalize", True):
            unnormalised.append(obj.name)
        matrix = obj.matrix_world
        direction = (matrix.to_quaternion() @ Vector((0.0, 0.0, -1.0))).normalized()
        lamp = {
            "name": obj.name,
            "position": to_gltf(matrix.translation),
            "direction": to_gltf(direction),
        }
        if data.type == "SUN":
            lamp["type"] = "sun"
            scale = energy
        elif data.type == "POINT":
            lamp["type"] = "point"
            scale = energy / (4.0 * math.pi)
        elif data.type == "SPOT":
            lamp["type"] = "spot"
            lamp["cone"] = round(float(data.spot_size), 5)
            lamp["blend"] = round(float(data.spot_blend), 4)
            scale = energy / (4.0 * math.pi)
        elif data.type == "AREA":
            lamp["type"] = "area"
            scale = energy / 4.0
        else:
            continue
        lamp["color"] = [round(c * scale, 6) for c in colour]
        lamps.append(lamp)
    if unnormalised:
        warnings.append("Normalize is off for %s; its brightness in VR is approximate" % names(unnormalised))
    if len(lamps) > MAX_LIGHTS:
        warnings.append("%d lamps in the scene; Vista shows the %d strongest" % (len(lamps), MAX_LIGHTS))
    return lamps, warnings


# ---- shape keys ---------------------------------------------------------------------------


def shape_key_objects(scene, selection_only):
    """Included meshes with shape keys, as (name, keys, vertices)."""
    result = []
    for obj in model_objects(scene, selection_only):
        if obj.type != "MESH" or obj.data.shape_keys is None:
            continue
        keys = max(0, len(obj.data.shape_keys.key_blocks) - 1)
        if keys:
            result.append((obj.name, keys, len(obj.data.vertices)))
    return result


# ---- the panel's check ---------------------------------------------------------------------


def plural(count, word):
    """"1 lamp", "3 lamps"."""
    return "%d %s%s" % (count, word, "" if count == 1 else "s")


def megabytes(count):
    return "%.0f MB" % (count / (1024 * 1024)) if count >= 10 * 1024 * 1024 else "%.1f MB" % (count / (1024 * 1024))


def inspect(context, selection_only, options):
    """Everything worth knowing before pressing Send, as (level, text) lines.

    level is "ERROR" (the send would be refused), "WARN" (it will arrive, but not as it looks
    here), "INFO" or "OK". [options] are the panel's toggles, so each line says what will
    actually happen with them as they are.
    """
    scene = context.scene
    lines = []
    depsgraph = context.evaluated_depsgraph_get()
    triangles, objects = count_triangles(depsgraph, selection_only)
    if objects == 0:
        lines.append(("ERROR", "Nothing to send: no visible objects%s"
                      % (" are selected" if selection_only else "")))
        return lines
    if triangles > MAX_TRIANGLES:
        lines.append(("ERROR", "%s triangles; Vista shows up to %s. Decimate, or send a selection."
                      % (format(triangles, ","), format(MAX_TRIANGLES, ","))))
    else:
        lines.append(("OK", "%s triangles in %s" % (format(triangles, ","), plural(objects, "object"))))

    size, images = texture_bytes(scene, selection_only)
    if images:
        level = "WARN" if size > 1024 * 1024 * 1024 else "INFO"
        lines.append((level, "%s, about %s on the headset" % (plural(images, "texture"), megabytes(size))))

    classes = materials_in_use(scene, selection_only)
    procedural = [n for n, c in classes.items() if c == "procedural"]
    unsupported = [n for n, c in classes.items() if c == "unsupported"]
    if procedural or unsupported:
        both = procedural + unsupported
        if options.get("bake"):
            lines.append(("INFO", "%s will be baked (%s)" % (plural(len(both), "procedural material"), names(both))))
        else:
            lines.append(("WARN", "%s will lose colour that glTF cannot carry: %s. Turn on Bake."
                          % (plural(len(both), "procedural material"), names(both))))

    keys = shape_key_objects(scene, selection_only)
    if keys:
        floats = sum(k * v * 3 for _, k, v in keys)
        if floats > MAX_MORPH_FLOATS:
            lines.append(("WARN", "Shape keys in %s are too large to animate in VR; the heaviest "
                          "will hold one shape" % names(n for n, _, _ in keys)))
        else:
            lines.append(("INFO", "Shape keys in %s" % names(n for n, _, _ in keys)))

    if options.get("environment", True):
        node = find_environment(scene.world)
        if node is None:
            lines.append(("INFO", "No World HDRI; Vista lights the model itself"))
        else:
            _, tilted = environment_yaw(node)
            width = node.image.size[0]
            text = "World HDRI %s" % node.image.name
            if width > MAX_ENV_WIDTH:
                text += ", reduced from %d to %d px wide" % (width, MAX_ENV_WIDTH)
            lines.append(("WARN" if tilted else "OK",
                          text + (". Its tilt (X/Y rotation) is not sent" if tilted else "")))

    if options.get("lights", True):
        lamps, warnings = lights(scene)
        if lamps:
            lines.append(("OK", plural(len(lamps), "lamp")))
        lines += [("WARN", w) for w in warnings]
    if options.get("cameras", True):
        cameras = viewpoints(scene)
        if cameras:
            lines.append(("OK", "%s to stand at in VR" % plural(len(cameras), "camera")))
    return lines
