# SPDX-License-Identifier: GPL-3.0-or-later
"""Runs inside a separate, background Blender on a snapshot of the user's scene.

    blender --background --factory-startup --disable-autoexec --python export_job.py -- \
        <snapshot.blend> <output dir> <options.json>

Writes one `<stem>.glb` — or one per variant — each with a `<stem>.vista.json` report that says
what glTF cannot: the World HDRI and how it is turned, the scene's cameras and lamps, the
variant, the note. Optionally `env-<hash>.hdr`, the World's HDRI itself. `manifest.json` lists
what was written, in the order it should be sent. Exits non-zero with the reason on stderr and
in `error.txt` when the scene cannot be sent, so the add-on can say why instead of "it failed".

Why a separate process: exporting can take a while on a big scene — baking materials longer
still — and doing it in the user's own Blender would freeze it for that long. It also means
nothing here can touch their file: this process only ever sees a copy.
"""
import hashlib
import json
import os
import re
import sys
import traceback

import bpy

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bake  # noqa: E402  (needs the path above)
import scene_check as check  # noqa: E402

MAX_VARIANTS = 12


class Refused(Exception):
    pass


def status(text):
    """One line the add-on shows while this runs. Flushed: the add-on reads the log as it grows."""
    print("VISTA-STATUS " + text, flush=True)


def parse_args():
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    if len(argv) != 3:
        raise Refused("export_job.py needs: snapshot.blend output_dir options.json")
    snapshot, out_dir, options_path = argv
    with open(options_path, encoding="utf-8") as f:
        options = json.load(f)
    return snapshot, out_dir, options


def shrink_textures(scene, selection_only):
    """Scales textures above MAX_TEXTURE_EDGE down to it. Only ever runs on the snapshot."""
    shrunk = 0
    seen = set()
    for obj in check.model_objects(scene, selection_only):
        for slot in obj.material_slots:
            mat = slot.material
            if mat is None or not check.uses_nodes(mat):
                continue
            for node in mat.node_tree.nodes:
                image = getattr(node, "image", None) if node.type == "TEX_IMAGE" else None
                if image is None or image.name in seen:
                    continue
                seen.add(image.name)
                width, height = image.size[0], image.size[1]
                edge = max(width, height)
                if edge <= check.MAX_TEXTURE_EDGE:
                    continue
                factor = check.MAX_TEXTURE_EDGE / edge
                image.scale(max(1, round(width * factor)), max(1, round(height * factor)))
                shrunk += 1
    return shrunk


# ---- the World ---------------------------------------------------------------------------


def write_environment(node, out_dir, warnings):
    """Writes the World HDRI as Radiance .hdr — the one format every Vista decodes."""
    image = node.image
    source = None
    if image.packed_file is None and image.source == "FILE":
        path = bpy.path.abspath(image.filepath, library=image.library)
        if os.path.isfile(path):
            source = path
    width, height = image.size[0], image.size[1]
    if width == 0 or height == 0:
        warnings.append("The World image %s could not be read, so no HDRI was sent" % image.name)
        return None

    tmp = os.path.join(out_dir, "env-tmp.hdr")
    if source and source.lower().endswith(".hdr") and width <= check.MAX_ENV_WIDTH:
        with open(source, "rb") as src, open(tmp, "wb") as dst:
            while True:
                block = src.read(1 << 20)
                if not block:
                    break
                dst.write(block)
    else:
        convert_to_hdr(image, tmp, warnings)

    # Named by content: the headset keeps it, and the next send of the same sky is skipped.
    name = "env-%s.hdr" % sha256(tmp)[:16]
    os.replace(tmp, os.path.join(out_dir, name))
    return name


def convert_to_hdr(image, path, warnings):
    import numpy as np

    width, height = image.size[0], image.size[1]
    if width > check.MAX_ENV_WIDTH:
        new_h = max(1, round(height * check.MAX_ENV_WIDTH / width))
        image.scale(check.MAX_ENV_WIDTH, new_h)
        warnings.append("The World HDRI was reduced to %dx%d for the headset" % (check.MAX_ENV_WIDTH, new_h))
        width, height = check.MAX_ENV_WIDTH, new_h
    pixels = np.empty(width * height * 4, dtype=np.float32)
    image.pixels.foreach_get(pixels)
    rgb = pixels.reshape(height, width, 4)[::-1, :, :3]  # Blender stores rows bottom-up
    if not image.is_float:
        # An 8-bit sky arrives sRGB-encoded; the headset lights in linear.
        rgb = np.where(rgb <= 0.04045, rgb / 12.92, ((rgb + 0.055) / 1.055) ** 2.4)
    write_radiance(path, np.ascontiguousarray(rgb, dtype=np.float32))


def write_radiance(path, rgb):
    """Radiance RGBE, flat scanlines, written directly.

    Not Image.save(): measured, it passes the pixels through the scene's view transform, which
    darkened an EXR's mean by 30 % and clipped its sun at 1.6. Lighting needs the radiance as
    it is, and RGBE is a dozen lines of numpy.
    """
    import numpy as np

    height, width = rgb.shape[:2]
    flat = np.maximum(rgb.reshape(-1, 3), 0.0)
    peak = flat.max(axis=1)
    mantissa, exponent = np.frexp(peak)
    visible = peak > 1e-32
    scale = np.zeros_like(peak)
    scale[visible] = mantissa[visible] * 256.0 / peak[visible]
    rgbe = np.zeros((flat.shape[0], 4), dtype=np.uint8)
    rgbe[:, :3] = np.clip(flat * scale[:, None], 0, 255).astype(np.uint8)
    rgbe[:, 3] = np.where(visible, exponent + 128, 0).astype(np.uint8)
    with open(path, "wb") as f:
        f.write(b"#?RADIANCE\nFORMAT=32-bit_rle_rgbe\n\n")
        f.write(("-Y %d +X %d\n" % (height, width)).encode())
        f.write(rgbe.tobytes())


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


# ---- variants ------------------------------------------------------------------------------


def _layer_collection(root, collection):
    if root.collection == collection:
        return root
    for child in root.children:
        found = _layer_collection(child, collection)
        if found is not None:
            return found
    return None


def find_variants(view_layer, name):
    """The sub-collections of the chosen collection, each one a variant of the scene."""
    parent = bpy.data.collections.get(name) if name else None
    if parent is None:
        raise Refused("Choose the collection whose sub-collections are the variants")
    variants = []
    for child in parent.children:
        layer = _layer_collection(view_layer.layer_collection, child)
        if layer is not None:
            variants.append((child, layer))
    if len(variants) < 2:
        raise Refused("%s has %d sub-collections in this view layer; variants need at least two"
                      % (parent.name, len(variants)))
    if len(variants) > MAX_VARIANTS:
        raise Refused("%s has %d sub-collections; up to %d variants are sent at once"
                      % (parent.name, len(variants), MAX_VARIANTS))
    return variants


def show_only(variants, chosen):
    """Puts one variant in the view layer and takes the others out.

    Whatever each was set to in the user's file: they switch variants by hiding all but one,
    so "currently hidden" says which they were looking at, not which they want sent.
    """
    for collection, layer in variants:
        visible = chosen is None or collection == chosen
        layer.exclude = not visible
        if visible:
            layer.hide_viewport = False
            collection.hide_viewport = False


def safe_name(text):
    """A collection name as part of a file name the headset will accept."""
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", text).strip(" .")[:40]
    return name or "Variant"


# ---- the glTF itself -----------------------------------------------------------------------


def export_gltf(path, selection_only, options):
    animations = bool(options.get("animations", True))
    wanted = dict(
        filepath=path,
        export_format="GLB",
        use_selection=selection_only,
        use_visible=True,
        use_active_scene=True,
        export_apply=True,
        export_yup=True,
        export_animations=animations,
        export_skins=animations,
        # Shape keys go as morph targets, with their normals so a deformed surface still
        # shades as one, and plainly stored: Vista reads sparse accessors, older Vistas do not.
        export_morph=True,
        export_morph_normal=True,
        export_morph_tangent=False,
        export_morph_animation=animations,
        export_try_sparse_sk=False,
        export_materials="EXPORT",
        export_image_format="AUTO",
        # Vista's parser does not decode Draco; uncompressed is also faster to load there.
        export_draco_mesh_compression_enable=False,
        # Cameras and lamps travel in the report instead: Vista reads them from there, in
        # Blender's own units, and a glTF reader that ignores them loses nothing.
        export_cameras=False,
        export_lights=False,
        export_extras=False,
    )
    if options.get("animationMode", "TIMELINE") == "ACTIONS":
        # Every action a clip of its own, to pick between on the headset.
        wanted["export_animation_mode"] = "ACTIONS"
    else:
        # The scene as it plays: one clip, sampled over the playback range, on the scene's own
        # clock — which is what lets Blender's playhead drive the headset's.
        wanted["export_animation_mode"] = "SCENE"
        wanted["export_anim_scene_split_object"] = False
        wanted["export_frame_range"] = True
    # Only what this Blender's exporter knows: an option it has dropped or not yet gained
    # must not turn a working export into a TypeError.
    known = set(bpy.ops.export_scene.gltf.get_rna_type().properties.keys())
    result = bpy.ops.export_scene.gltf(**{k: v for k, v in wanted.items() if k in known})
    if "FINISHED" not in result or not os.path.isfile(path):
        raise Refused("Blender's glTF exporter did not produce a file")
    size = os.path.getsize(path)
    if size > check.MAX_MODEL_BYTES:
        raise Refused("The export is %d MB; Vista opens models up to %d MB. Send a selection, "
                      "or simplify the heaviest meshes."
                      % (size // (1024 * 1024), check.MAX_MODEL_BYTES // (1024 * 1024)))
    return size


def count_or_refuse(selection_only, what=""):
    triangles, objects = check.count_triangles(bpy.context.evaluated_depsgraph_get(), selection_only)
    if objects == 0:
        raise Refused("Nothing to send%s: no visible objects%s"
                      % (what, " are selected" if selection_only else ""))
    if triangles > check.MAX_TRIANGLES:
        raise Refused("The scene%s has %s triangles; Vista shows up to %s. Decimate it or send a selection."
                      % (what, format(triangles, ","), format(check.MAX_TRIANGLES, ",")))
    return triangles, objects


def export(snapshot, out_dir, options):
    bpy.ops.wm.open_mainfile(filepath=snapshot, load_ui=False, use_scripts=False)
    scene = bpy.context.scene
    scope = options.get("scope", "SCENE")
    selection_only = scope == "SELECTION"
    stem = options["stem"]
    warnings = []

    if bpy.context.object is not None and bpy.context.object.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    variants = find_variants(bpy.context.view_layer, options.get("variantsCollection")) if scope == "VARIANTS" else []
    if variants:
        # Everything in, for the steps that concern the whole scene: counting what there is to
        # bake, shrinking textures, reading the World.
        show_only(variants, None)

    status("Checking the scene…")
    if not variants:
        count_or_refuse(selection_only)

    baked = set()
    if options.get("bake", True):
        baked = bake.bake_procedural(scene, selection_only, int(options.get("bakeSize", 1024)),
                                     out_dir, warnings, status)
    warnings += check.material_warnings(scene, selection_only)

    keys = check.shape_key_objects(scene, selection_only)
    if sum(k * v * 3 for _, k, v in keys) > check.MAX_MORPH_FLOATS:
        warnings.append("Shape keys in %s are too large to animate in VR; the heaviest hold one shape"
                        % check.names(n for n, _, _ in keys))

    shrunk = shrink_textures(scene, selection_only)
    if shrunk:
        print("VISTA textures reduced to %d px: %d" % (check.MAX_TEXTURE_EDGE, shrunk))

    environment, yaw, strength = None, None, 1.0
    if options.get("environment", True):
        node = check.find_environment(scene.world)
        if node is not None:
            status("Preparing the HDRI…")
            environment = write_environment(node, out_dir, warnings)
            if environment is not None:
                yaw, tilted = check.environment_yaw(node)
                strength = check.environment_strength(node)
                if tilted:
                    warnings.append("The World is tilted (rotated about X or Y); only its turn "
                                    "about Z is sent, so the sky may sit differently in VR")

    cameras = check.viewpoints(scene) if options.get("cameras", True) else []
    fps = scene.render.fps / scene.render.fps_base
    common = {
        "schema": "vista-bridge/2",
        "environment": environment,
        "environmentStrength": round(strength, 5),
        "note": str(options.get("note", ""))[:200],
        "sourceFile": options.get("source", ""),
        "blender": bpy.app.version_string,
        "scope": scope.lower(),
        "unitScale": scene.unit_settings.scale_length if scene.unit_settings.system != "NONE" else 1.0,
        "viewpoints": cameras,
        "baked": len(baked),
        "timeline": {"fps": round(fps, 4), "start": scene.frame_start, "end": scene.frame_end},
    }
    if yaw is not None:
        common["environmentYaw"] = round(yaw, 6)

    reports = []
    jobs = [(None, stem)] if not variants else [
        (collection, "%s-%d %s" % (stem, index + 1, safe_name(collection.name)))
        for index, (collection, _) in enumerate(variants)]
    for index, (collection, name) in enumerate(jobs):
        own = list(warnings)
        if collection is not None:
            show_only(variants, collection)
            status("Exporting variant %d/%d: %s" % (index + 1, len(jobs), collection.name))
            triangles, objects = count_or_refuse(False, " in variant " + collection.name)
        else:
            status("Exporting…")
            triangles, objects = count_or_refuse(selection_only)

        lamps = []
        if options.get("lights", True):
            # Per variant: a lamp inside a variant's collection belongs to that variant.
            lamps, lamp_warnings = check.lights(scene)
            own += lamp_warnings

        output = os.path.join(out_dir, name + ".glb")
        size = export_gltf(output, selection_only, options)
        report = dict(common)
        report.update({
            "outputFile": os.path.basename(output),
            "triangles": triangles,
            "objects": objects,
            "actions": len(bpy.data.actions) if options.get("animations", True) else 0,
            "lights": lamps,
            "outputBytes": size,
            "outputSha256": sha256(output),
            "warnings": own,
        })
        if collection is not None:
            report.update({"set": stem, "variant": collection.name,
                           "variantIndex": index, "variantCount": len(jobs)})
        report_name = name + ".vista.json"
        with open(os.path.join(out_dir, report_name), "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        reports.append(report_name)

    with open(os.path.join(out_dir, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump({"reports": reports, "environment": environment}, f)


def main():
    out_dir = None
    try:
        snapshot, out_dir, options = parse_args()
        export(snapshot, out_dir, options)
    except Refused as refused:
        message = str(refused)
    except Exception:
        message = "Export failed:\n" + traceback.format_exc()
    else:
        sys.exit(0)
    print("VISTA-ERROR " + message, file=sys.stderr)
    if out_dir:
        with open(os.path.join(out_dir, "error.txt"), "w", encoding="utf-8") as f:
            f.write(message)
    sys.exit(2)


main()
