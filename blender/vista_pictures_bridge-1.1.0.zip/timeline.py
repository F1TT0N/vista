# SPDX-License-Identifier: GPL-3.0-or-later
"""Tells the headsets where Blender's playhead is. No bpy: the sending runs on its own thread.

Blender's frame-change handler runs on every frame of a scrub or of playback, in the middle
of Blender updating the scene, so it must cost nothing: it leaves the newest position here and
returns. A worker thread sends it. Only the NEWEST — a position that was not sent before the
next one arrived is already wrong, and sending it anyway would make the headset trail behind.
"""
import threading
import time

from . import transport

# Twenty a second is as fast as a hand scrubs and as much as Wi-Fi does without queueing.
MIN_INTERVAL_S = 0.05
# A headset that did not answer is left alone for this long, so one that is asleep does not
# hold up the others on every frame.
RETRY_AFTER_S = 5.0


class TimelineSync:
    def __init__(self):
        self._lock = threading.Lock()
        self._wake = threading.Event()
        self._latest = None
        self._thread = None
        self._clients = {}
        self._failed_at = {}
        self.last_error = ""

    def push(self, headsets, project, seconds, playing):
        """Called from Blender's handler. [headsets] is a list of (address, username, password)."""
        with self._lock:
            self._latest = (tuple(headsets), project, seconds, playing)
            if self._thread is None or not self._thread.is_alive():
                self._thread = threading.Thread(target=self._run, name="vista-timeline", daemon=True)
                self._thread.start()
        self._wake.set()

    def _run(self):
        idle_since = time.monotonic()
        while True:
            self._wake.wait(1.0)
            self._wake.clear()
            with self._lock:
                job, self._latest = self._latest, None
                if job is None:
                    # Nothing for a while: let the thread end. The next push starts another.
                    if time.monotonic() - idle_since > 30.0:
                        self._thread = None
                        return
                    continue
            idle_since = time.monotonic()
            headsets, project, seconds, playing = job
            for spec in headsets:
                self._send(spec, project, seconds, playing)
            time.sleep(MIN_INTERVAL_S)

    def _send(self, spec, project, seconds, playing):
        now = time.monotonic()
        if now - self._failed_at.get(spec, -RETRY_AFTER_S) < RETRY_AFTER_S:
            return
        try:
            client = self._clients.get(spec)
            if client is None:
                client = self._clients[spec] = transport.VistaClient(*spec)
            client.timeline(project, seconds, playing)
            self.last_error = ""
        except (transport.BridgeError, ConnectionError, OSError) as error:
            self._failed_at[spec] = now
            self.last_error = str(error)
