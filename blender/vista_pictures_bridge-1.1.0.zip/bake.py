# SPDX-License-Identifier: GPL-3.0-or-later
"""Bakes colours glTF cannot carry — procedural textures, shaders without a Principled BSDF —
into image textures, so the model looks in VR as it does in Blender.

Only ever runs in the background export, on the snapshot: it rewrites materials, adds a UV
map and switches the render engine, none of which may touch the user's file.

How: for each mesh that wears such a material, every material on it is baked into ONE image
over a fresh, non-overlapping UV layout, and the materials are rewired to read their colour
from it. The whole mesh rather than just the procedural slots, because Vista reads one UV set
(TEXCOORD_0): a mesh cannot keep its authored UVs for some materials and use a bake layout
for others. The colour is baked as emission, not as a diffuse pass — a diffuse pass of a metal
is black, since a metal has no diffuse — so what lands in the image is exactly what was
plugged into Base Color.
"""
import math
import os

import bpy

from scene_check import classify_material, model_objects, uses_nodes

UV_NAME = "VistaBake"
# Beyond this the export would spend longer baking than the user will wait for a preview.
MAX_MESHES = 48


def _surface_colour_socket(tree):
    """(output node, socket whose value IS the surface colour), or (output, None)."""
    outputs = [n for n in tree.nodes if n.type == "OUTPUT_MATERIAL"]
    outputs.sort(key=lambda n: not n.is_active_output)
    output = outputs[0] if outputs else None
    principled = [n for n in tree.nodes if n.type == "BSDF_PRINCIPLED"]
    if principled:
        return output, principled[0].inputs.get("Base Color")
    if output is None or not output.inputs["Surface"].is_linked:
        return output, None
    # No Principled: walk back from the output to the first shader that has a colour at all.
    seen, stack = set(), [output.inputs["Surface"].links[0].from_node]
    while stack:
        node = stack.pop(0)
        if node.name in seen:
            continue
        seen.add(node.name)
        for name in ("Base Color", "Color"):
            socket = node.inputs.get(name)
            if socket is not None and socket.type == "RGBA":
                return output, socket
        for inp in node.inputs:
            for link in inp.links:
                stack.append(link.from_node)
    return output, None


class _Rewired:
    """One material temporarily turned into "emit my surface colour", and how to finish it."""

    def __init__(self, material, image):
        self.material = material
        tree = material.node_tree
        self.output, self.colour = _surface_colour_socket(tree)
        if self.output is None:
            self.output = tree.nodes.new("ShaderNodeOutputMaterial")
        surface = self.output.inputs["Surface"]
        self.original = surface.links[0].from_socket if surface.is_linked else None

        self.emission = tree.nodes.new("ShaderNodeEmission")
        if self.colour is not None and self.colour.is_linked:
            tree.links.new(self.emission.inputs["Color"], self.colour.links[0].from_socket)
        elif self.colour is not None:
            self.emission.inputs["Color"].default_value = self.colour.default_value
        else:
            self.emission.inputs["Color"].default_value = (0.8, 0.8, 0.8, 1.0)
        tree.links.new(surface, self.emission.outputs["Emission"])

        # The image node the bake writes into: it has to be the ACTIVE node of every material
        # on the object, which is the one thing Blender's bake goes by.
        self.texture = tree.nodes.new("ShaderNodeTexImage")
        self.texture.image = image
        for node in tree.nodes:
            node.select = False
        self.texture.select = True
        tree.nodes.active = self.texture

    def finish(self):
        """Back to a real surface, now reading its colour from the baked image."""
        tree = self.material.node_tree
        surface = self.output.inputs["Surface"]
        tree.nodes.remove(self.emission)
        principled = [n for n in tree.nodes if n.type == "BSDF_PRINCIPLED"]
        if principled:
            if self.original is not None:
                tree.links.new(surface, self.original)
            target = principled[0]
        else:
            # A shader the exporter cannot read at all becomes a plain Principled wearing the
            # bake: the colour is right, which is everything Vista would have shown of it.
            target = tree.nodes.new("ShaderNodeBsdfPrincipled")
            target.inputs["Roughness"].default_value = 0.5
            tree.links.new(surface, target.outputs["BSDF"])
        tree.links.new(target.inputs["Base Color"], self.texture.outputs["Color"])


def _bake_mesh(scene, obj, size, out_dir, index):
    mesh = obj.data
    view_layer = bpy.context.view_layer
    for other in view_layer.objects:
        other.select_set(False)
    obj.select_set(True)
    view_layer.objects.active = obj

    # A layout of its own, every face on its own piece of the image.
    layer = mesh.uv_layers.get(UV_NAME) or mesh.uv_layers.new(name=UV_NAME)
    if layer is None:
        # Eight UV maps already: make room by dropping the last, which the bake replaces anyway.
        mesh.uv_layers.remove(mesh.uv_layers[-1])
        layer = mesh.uv_layers.new(name=UV_NAME)
    mesh.uv_layers.active = layer
    layer.active_render = True
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    bpy.ops.uv.smart_project(angle_limit=math.radians(66.0), island_margin=0.02)
    bpy.ops.object.mode_set(mode="OBJECT")

    image = bpy.data.images.new("vista-bake-%03d" % index, size, size, alpha=False)
    rewired = []
    for slot in obj.material_slots:
        material = slot.material
        if material is None:
            continue
        # A copy: the material may dress other meshes too, each of which gets its own image.
        copy = material.copy()
        if not uses_nodes(copy):
            copy.use_nodes = True
        slot.material = copy
        rewired.append(_Rewired(copy, image))
    if not rewired:
        bpy.data.images.remove(image)
        return False

    bpy.ops.object.bake(type="EMIT", margin=max(2, size // 128), use_clear=True)

    path = os.path.join(out_dir, "bake-%03d.png" % index)
    image.filepath_raw = path
    image.file_format = "PNG"
    image.save()
    for item in rewired:
        item.finish()
    # The bake layout becomes the mesh's ONLY UV map, so it is the one exported as TEXCOORD_0.
    for name in [l.name for l in mesh.uv_layers if l.name != UV_NAME]:
        mesh.uv_layers.remove(mesh.uv_layers[name])
    return True


def bake_procedural(scene, selection_only, size, out_dir, warnings, status):
    """Bakes every included mesh that wears a material glTF cannot carry.

    Returns the names of the materials that were baked, so they are not warned about again.
    """
    wanted = {}
    skipped = []
    for obj in model_objects(scene, selection_only):
        needs = [slot.material.name for slot in obj.material_slots
                 if slot.material is not None
                 and classify_material(slot.material) in {"procedural", "unsupported"}]
        if not needs:
            continue
        if obj.type != "MESH" or obj.data.library is not None or not obj.data.polygons:
            skipped.append(obj.name)
            continue
        # One bake per mesh, not per object: linked duplicates share the mesh, its UVs and its
        # materials, so the first of them bakes for all.
        wanted.setdefault(obj.data.name, (obj, needs))
    if skipped:
        warnings.append("Procedural colour on %s cannot be baked (not an editable mesh)"
                        % ", ".join(skipped[:3]))
    if not wanted:
        return set()

    jobs = list(wanted.values())
    if len(jobs) > MAX_MESHES:
        warnings.append("%d meshes have procedural colour; the first %d were baked"
                        % (len(jobs), MAX_MESHES))
        jobs = jobs[:MAX_MESHES]

    scene.render.engine = "CYCLES"
    scene.cycles.device = "CPU"
    scene.cycles.samples = 1
    scene.cycles.use_denoising = False
    scene.render.bake.use_selected_to_active = False
    scene.render.bake.target = "IMAGE_TEXTURES"

    # Emission does not depend on anything else in the scene, so nothing else needs to be
    # there: with the rest hidden from rendering, each bake syncs one object instead of all.
    hidden = {o.name: o.hide_render for o in scene.objects}
    for o in scene.objects:
        o.hide_render = True
    baked = set()
    try:
        for index, (obj, needs) in enumerate(jobs):
            status("Baking materials %d/%d: %s" % (index + 1, len(jobs), obj.name))
            obj.hide_render = False
            try:
                if _bake_mesh(scene, obj, size, out_dir, index):
                    baked.update(needs)
            except RuntimeError as error:
                # One object that will not bake costs that object its colour, not the send.
                warnings.append("Could not bake %s: %s" % (obj.name, str(error).strip().splitlines()[-1]))
                if bpy.context.object is not None and bpy.context.object.mode != "OBJECT":
                    bpy.ops.object.mode_set(mode="OBJECT")
            obj.hide_render = True
    finally:
        for o in scene.objects:
            o.hide_render = hidden.get(o.name, False)
    return baked
