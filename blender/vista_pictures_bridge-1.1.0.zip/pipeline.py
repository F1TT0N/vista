# SPDX-License-Identifier: GPL-3.0-or-later
"""Export a scene snapshot and send it to the headsets. No bpy: this runs on a worker thread.

Kept apart from the operator so that exactly this code — not a copy of it — is what the
end-to-end tests drive against a real headset.
"""
import json
import pathlib
import subprocess
import time

from . import transport

EXPORT_TIMEOUT_S = 30 * 60


class Sender:
    """Sends a set of files to every headset, one after the other.

    [headsets] is a list of (name, VistaClient). A headset that cannot be reached, or refuses,
    costs that headset the send and not the others: with a room of them, one that is asleep
    must not stop the rest from showing the scene.

    [post] receives ("progress"|"status"|"done"|"error", text, extra).
    """

    def __init__(self, headsets, post, cancel):
        self.headsets = list(headsets)
        self.post = post
        self.cancel = cancel

    def send_all(self, project, uploads, skippable=()):
        """Uploads [uploads] — (path, destination under the project) pairs, in order.

        A destination in [skippable] is one named by its content: if the headset already has
        it at that size it is not sent again.

        Returns the names of the headsets that have everything, and why the others do not.
        """
        reached, failed = [], []
        count = len(self.headsets)
        for index, (name, client) in enumerate(self.headsets):
            prefix = "%s: " % name if count > 1 else ""
            try:
                self._send_one(client, project, uploads, skippable, prefix, index, count)
                reached.append(name)
            except InterruptedError:
                raise
            except (transport.BridgeError, ConnectionError, OSError) as error:
                failed.append("%s: %s" % (name, error) if count > 1 else str(error))
        return reached, failed

    def _send_one(self, client, project, uploads, skippable, prefix, index, count):
        pending = []
        for path, destination in uploads:
            path = pathlib.Path(path)
            if destination in skippable and client.exists(project + "/" + destination, path.stat().st_size):
                self.post("status", prefix + "HDRI already on the Quest", None)
                continue
            pending.append((path, destination))
        total = sum(path.stat().st_size for path, _ in pending) or 1
        sent = 0
        for path, destination in pending:
            label = {".hdr": "HDRI", ".glb": "model", ".json": "report"}.get(path.suffix, "picture")

            def progress(done, _size, base=sent, label=label):
                within = (base + done) / total
                self.post("progress", "%sSending %s… %d%%" % (prefix, label, 100 * within),
                          0.3 + 0.7 * (index + within) / count)

            client.upload(path, project + "/" + destination, self.cancel.is_set, progress)
            sent += path.stat().st_size


class Job:
    """One send of the scene: export once, then to every headset."""

    def __init__(self, blender, folder, snapshot, stem, project, headsets, post, cancel):
        self.blender = blender
        self.folder = pathlib.Path(folder)
        self.snapshot = pathlib.Path(snapshot)
        self.stem = stem
        self.project = project
        self.sender = Sender(headsets, post, cancel)
        self.post = post
        self.cancel = cancel
        self.process = None

    def run(self):
        try:
            manifest = self.export()
            self.send(manifest)
        except InterruptedError:
            self.post("error", "Cancelled", None)
        except (transport.BridgeError, ConnectionError, OSError, ValueError, KeyError) as error:
            self.post("error", str(error), None)
        except Exception as error:  # a bug of ours; still say so rather than hang the panel
            self.post("error", "Unexpected error: %r" % error, None)

    def export(self):
        script = pathlib.Path(__file__).with_name("export_job.py")
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        log_path = self.folder / "export.log"
        with log_path.open("wb") as log:
            self.process = subprocess.Popen(
                [self.blender, "--background", "--factory-startup", "--disable-autoexec",
                 "--python", str(script), "--",
                 str(self.snapshot), str(self.folder), str(self.folder / "options.json")],
                stdout=log, stderr=subprocess.STDOUT, creationflags=flags)
            deadline = time.monotonic() + EXPORT_TIMEOUT_S
            self.post("progress", "Exporting…", 0.05)
            said = None
            while self.process.poll() is None:
                if self.cancel.wait(0.25):
                    self._stop()
                    raise InterruptedError()
                if time.monotonic() > deadline:
                    self._stop()
                    raise transport.BridgeError("The export took longer than %d minutes" % (EXPORT_TIMEOUT_S // 60))
                now = _last_status(log_path)
                if now and now != said:
                    said = now
                    self.post("progress", now, 0.15)
        if self.process.returncode != 0:
            error = self.folder / "error.txt"
            if error.is_file():
                raise transport.BridgeError(error.read_text(encoding="utf-8").strip())
            raise transport.BridgeError("The export failed; see the log: " + str(log_path))
        return json.loads((self.folder / "manifest.json").read_text(encoding="utf-8"))

    def send(self, manifest):
        reports = [json.loads((self.folder / name).read_text(encoding="utf-8")) for name in manifest["reports"]]
        uploads = []
        skippable = set()
        env = manifest.get("environment")
        if env:
            # Named by content, so "already there" means "the same sky": skip the 100 MB.
            uploads.append((self.folder / env, env))
            skippable.add(env)
        for name, report in zip(manifest["reports"], reports):
            # Each report goes after its model: it is what tells the headset the scene is complete.
            uploads.append((self.folder / report["outputFile"], report["outputFile"]))
            uploads.append((self.folder / name, name))

        reached, failed = self.sender.send_all(self.project, uploads, skippable)
        if not reached:
            raise transport.BridgeError(failed[0] if failed else "No headset to send to")

        first = reports[0]
        triangles = max(r.get("triangles", 0) for r in reports)
        what = first["outputFile"] if len(reports) == 1 else "%d variants" % len(reports)
        summary = "Sent %s to %s (%s triangles)" % (what, self.project, format(triangles, ","))
        if len(self.sender.headsets) > 1:
            summary += " on %d of %d headsets" % (len(reached), len(self.sender.headsets))
        if first.get("baked"):
            summary += ", %d material%s baked" % (first["baked"], "" if first["baked"] == 1 else "s")
        warnings = list(failed)
        for report in reports:
            warnings += [w for w in report.get("warnings") or [] if w not in warnings]
        self.post("done", summary, warnings)

    def _stop(self):
        self.process.terminate()
        try:
            self.process.wait(5)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait()


class RenderJob:
    """Sends a picture that is already on disk — the render — to every headset."""

    def __init__(self, path, name, project, headsets, post, cancel):
        self.path = pathlib.Path(path)
        self.name = name
        self.project = project
        self.sender = Sender(headsets, post, cancel)
        self.post = post

    def run(self):
        try:
            self.post("progress", "Sending render…", 0.3)
            reached, failed = self.sender.send_all(
                self.project, [(self.path, "renders/" + self.name)])
            if not reached:
                raise transport.BridgeError(failed[0] if failed else "No headset to send to")
            summary = "Sent render %s to %s" % (self.name, self.project)
            if len(self.sender.headsets) > 1:
                summary += " on %d of %d headsets" % (len(reached), len(self.sender.headsets))
            self.post("done", summary, failed)
        except InterruptedError:
            self.post("error", "Cancelled", None)
        except (transport.BridgeError, ConnectionError, OSError, ValueError) as error:
            self.post("error", str(error), None)
        except Exception as error:
            self.post("error", "Unexpected error: %r" % error, None)


def _last_status(log_path):
    """The newest "VISTA-STATUS" line of the export's log, read from its tail."""
    try:
        with open(log_path, "rb") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 8192))
            tail = f.read().decode("utf-8", "replace")
    except OSError:
        return None
    for line in reversed(tail.splitlines()):
        if line.startswith("VISTA-STATUS "):
            return line[len("VISTA-STATUS "):].strip()
    return None
